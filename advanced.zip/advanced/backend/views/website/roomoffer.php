<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'RoomOffer';
$this->params['breadcrumbs'][] = $this->title;
?>
 
  <div >
    <img src="uploads/roomoffer1.jpg" style="width:100%;height:20%;"> 
  
  </div>

<div>
<h1> OFFERS AND ACTIVITIES </h1>
<hr class = "hrColor">
<h2>ROOM OFFERS</h2>
<hr class = "hrColor">
<h3>FAMILY PACKAGE</h3>
 <img src="uploads/roomoffer.jpg" style="width:40%;height:40%;"> 
 <div class="bullet">
    <p>
    	</br>
     <strong> Any day is always a great day for a family escapade at Pico Sands Hotel.</strong> </br>  </br>Book now and pay a starting rate of PHP 9,900 a night on our <strong> Premier Mountain View Room</strong>  </br> </br>or </br></br> PHP 10,900 a night on our <strong> Premier Lagoon View Room</strong>  using this special promo!
</br>
Promo is applicable for stays until <strong>September 15, 2017 </strong>   	
    	
    </p>
<br>
    <a class="btn btn-lg btn-success" href="http://localhost/yii/web/index.php?r=site%2Fabout">Read More</a>

   </div>
   </div>