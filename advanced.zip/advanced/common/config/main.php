<?php
return [
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
        'cache' => [
            'class' => 'yii\caching\FileCache',

        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => false,
            'transport' => [
                    'class' => 'Swift_SmtpTransport',
                     'host'=>'smtp.gmail.com',
                    //'username'=>'shierenecervantes23@gmail.com',
                    //'password'=>"ATWTFG2357",
                    'username'=>'noelleshierenecervantes@gmail.com',
                    'password'=>'passwordistgbtg',
                    'port' => '465',
                    'encryption' => 'ssl',
        ],
        ],
    ],

];
